<?php get_template_part('template-parts/header'); ?>
	<div>
		<div class="page-content">
			<p>Page not found</p>			
		</div><!-- .page-content -->
	</div><!-- .error-404 -->
<?php get_template_part('template-parts/footer'); ?>
