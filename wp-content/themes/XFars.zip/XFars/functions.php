<?php

/**get url theme directiory  */
define('THEME_URL',get_stylesheet_directory());

/** setup theme */
if (!function_exists('XFars_theme_setup')){
    function XFars_theme_setup(){
        /**setup textdomain */
        $language_folder = THEME_URL.'/languages';
        load_theme_textdomain('Xfars',$language_folder);

        /** add post thumbnail */
        add_theme_support('post-thumbnails');

        /**Custom background */
        $default_background = array(
            'default-color' => '#e8e8e8'
        );
        add_theme_support('custom-background',$default_background);

        /**register menu */        
        register_nav_menu('primary-menu',__('Primary Menu','XFars'));

        /**Add support for automatic feed links. */      
        add_theme_support( 'automatic-feed-links' );

    }
    // init setup
    add_action('init','XFars_theme_setup');
}

/**
 * Register widget areas.
 */
function xfars_widgets_init() {
    register_sidebar( array(
      'name'          => __( 'Sidebar', 'xfars' ),
      'id'            => 'sidebar-1',
      'before_widget' => '<section id="%1$s" class="widget %2$s">',
      'after_widget'  => '</section>',
      'before_title'  => '<h2 class="widget-title">',
      'after_title'   => '</h2>'
    ) );
  
    register_sidebar( array(
      'name'          => __( 'Footer', 'xfars' ),
      'id'            => 'footer-1',
      'before_widget' => '<section id="%1$s" class="widget %2$s">',
      'after_widget'  => '</section>',
      'before_title'  => '<h2 class="widget-title">',
      'after_title'   => '</h2>'
    ) );
  }
  add_action( 'widgets_init', 'xfars_widgets_init' );


/**
 * import style,plugin,script for site
 */

add_action('wp_enqueue_scripts', 'xfars_theme_register_style');

add_action('wp_enqueue_scripts', 'xfars_theme_register_script');

/**load css */
function xfars_theme_register_style()
{
    $cssUrl = get_template_directory_uri() . '/assets/css';
    wp_register_style('xfars_theme_font-awesome', $cssUrl . '/font-awesome.min.css', array(), '1.0');
    wp_enqueue_style('xfars_theme_font-awesome');

    wp_register_style('xfars_theme_flaticon', $cssUrl . '/flaticon.css', array(), '1.0');
    wp_enqueue_style('xfars_theme_flaticon');


    /** Theme style custom */
    wp_register_style('xfars_theme_style', $cssUrl . '/style.css', array(), '1.0');
    wp_enqueue_style('xfars_theme_style');

    /**Theme Responsive css */
    wp_register_style('xfars_theme_responsive', $cssUrl . '/responsive.css', array(), '1.0');
    wp_enqueue_style('xfars_theme_responsive');


    /** add plugins */
    wp_register_style('xfars_theme_bootstrap', $cssUrl . '/bootstrap.min.css', array(), '1.0');
    wp_enqueue_style('xfars_theme_bootstrap');

    wp_register_style('xfars_theme_animate', $cssUrl . '/animate.css', array(), '1.0');
    wp_enqueue_style('xfars_theme_animate');

    wp_register_style('xfars_theme_owl.carousel', $cssUrl . '/owl.carousel.css', array(), '1.0');
    wp_enqueue_style('xfars_theme_owl.carousel');

    wp_register_style('xfars_theme_owl-theme', $cssUrl . '/owl.theme.css', array(), '1.0');
    wp_enqueue_style('xfars_theme_owl-theme');

    wp_register_style('xfars_theme_owl-transitions', $cssUrl . '/owl.transitions.css', array(), '1.0');
    wp_enqueue_style('xfars_theme_owl-theme');

    wp_register_style('xfars_theme_jquery-barfiller', $cssUrl . '/jquery.barfiller.css', array(), '1.0');
    wp_enqueue_style('xfars_theme_jquery-barfiller');
}
    /**LoadJS */
function xfars_theme_register_script(){
    $jsUrl = get_template_directory_uri() . '/assets/js';
    wp_register_script('xfars_theme_jquery-1.12',$jsUrl.'/vendor/jquery-1.12.0.min.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_jquery-1.12');

    wp_register_script('xfars_theme_plugins',$jsUrl.'/plugins.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_plugins');

    wp_register_script('xfars_theme_Popper',$jsUrl.'/Popper.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_Popper');
    
    wp_register_script('xfars_theme_bootstrap_js',$jsUrl.'/bootstrap.min.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_bootstrap_js');

    wp_register_script('xfars_theme_jquery_magnific',$jsUrl.'/jquery.magnific-popup.min.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_jquery_magnific');

    wp_register_script('xfars_theme_owl-carousel',$jsUrl.'/owl.carousel.min.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_owl-carousel');

    wp_register_script('xfars_theme_isotope',$jsUrl.'/isotope.pkgd.min.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_isotope');

    wp_register_script('xfars_theme_imagesloaded',$jsUrl.'/imagesloaded.pkgd.min.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_imagesloaded');

    wp_register_script('xfars_theme_scrollup',$jsUrl.'/scrollup.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_scrollup');

    wp_register_script('xfars_theme_jquery_counterup',$jsUrl.'/jquery.counterup.min.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_jquery_counterup');

    wp_register_script('xfars_theme_main',$jsUrl.'/main.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_main');

    wp_register_script('xfars_theme_waypoints',$jsUrl.'/waypoints.min.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_waypoints');


    wp_register_script('xfars_theme_jquery_appear',$jsUrl.'/jquery.appear.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_jquery_appear');

    wp_register_script('xfars_theme_jquery_barfiller',$jsUrl.'/jquery.barfiller.js',array(),'1.0',true);
    wp_enqueue_script('xfars_theme_jquery_barfiller');

    wp_register_script('xfars_theme_modernizr-2.8.3',$jsUrl.'/vendor/modernizr-2.8.3-respond-1.4.2.min.js',array(),'1.0',false);
    wp_enqueue_script('xfars_theme_modernizr-2.8.3');


}

if ( function_exists( 'xfars_pagination' ) ) {
    xfars_pagination();
}

function xfars_pagination() {
    global $wp_query;

    $total_pages = $wp_query->max_num_pages;

    if ( $total_pages > 1 ) {
        $current_page = max( 1, get_query_var( 'paged' ) );

        return'<div class="pagination">';
             paginate_links( array(
                'base' => get_pagenum_link( 1 ) . '%_%',
                'format' => '/page/%#%',
                'current' => $current_page,
                'total' => $total_pages,
                'prev_text' => '&laquo; Previous',
                'next_text' => 'Next &raquo;',
            ) );
        '</div>';
    }else{
        return '';
    }
}

