<?php get_template_part('template-parts/header'); ?>
<!-- menu area start here -->
<?php get_sidebar('menu'); ?>
<!-- end menu area -->

<!-- banner area start here -->
<div class="banner-area">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="banner-content">
                    <div class="banner-title">
                        <h1>Explor your Dreams Life</h1>
                    </div>
                    <div class="banner-subtitle">
                        <h4>Tour & Travel bloging</h4>
                    </div>
                    <div class="social-media">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                            <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            <li><a href="#"><i class="fa fa-behance"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="banner-img">
                    <img src="<?php bloginfo('template_directory'); ?>/assets/images/banner/1.png" alt="banner">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- banner area start here -->
<!-- secendary menu area start here -->
<div class="secendary-menu-area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="secendary-menu">
                    <nav>
                        <ul>
                            <li class="active"><a href="#"> <span class="flaticon-sunset"></span> Travel </a></li>
                            <li><a href="#"> <span class="flaticon-worldwide"></span> World Tour </a></li>
                            <li><a href="#"> <span class="flaticon-boat"></span> Ship tour </a></li>
                            <li><a href="#"> <span class="flaticon-sunset"></span> Sea Tour </a></li>
                            <li><a href="#"> <span class="flaticon-museum"></span> Guide </a></li>
                            <li><a href="#"> <span class="flaticon-video-camera"></span> Fashion </a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- secendary menu area start here -->
<!-- post area start here	 -->
<div class="post-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 col-lg-offset-1 col-md-12">
                <?php while (have_posts()) : the_post(); ?>
                    <div class="single-post">
                        <div class="inner-post">
                            <div class="post-img">
                                <a href="#"><img src="<?php bloginfo('template_directory'); ?>assets/images/blog/1.png" alt="blog"></a>
                            </div>
                            <div class="post-info">
                                <div class="post-title">
                                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                </div>
                                <div class="post-content">
                                    <p><?php the_content() ?> </p>
                                </div>
                                <div class="blog-meta fix">
                                    <div class="meta-left pull-left">
                                        <ul>
                                            <li> <span class="flaticon-man-user user"></span>
                                                <p>By <a href="#"><?php the_author(); ?></a> </p>
                                            </li>
                                            <li> <span class="flaticon-calendar clendar"></span>
                                                <p><?php the_date(); ?></p>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="post-readmore pull-right">
                                        <a href="#" class="readmore-btn">Read More <span>+</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="post-date one">
                            <span>01</span>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
            <div class="col-lg-10 col-lg-offset-1 col-md-12">
                <div class="pagination-area">
                    <div class="pagination">
                        <?php xfars_pagination(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- leaf left area start here	 -->
    <div class="leaf-left">
        <img src="<?php bloginfo('template_directory'); ?>/assets/images/leaf-left.png" alt="leaf-right">
    </div>
    <!-- leaf left area end here	 -->
    <!-- leaf right area start here	 -->
    <div class="leaf-right">
        <img src="<?php bloginfo('template_directory'); ?>/assets/images/leaf-right.png" alt="leaf-right">
    </div>
    <!-- leaf right area end here	 -->
</div>
<!-- post area end here	 -->

<?php get_template_part('template-parts/footer') ?>
