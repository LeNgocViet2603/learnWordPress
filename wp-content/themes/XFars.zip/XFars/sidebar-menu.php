<div class="sidebar-menu">
    <div class="close-area">
        <span class="close"><i class="icon fa fa-times-circle"></i></span>
    </div>
    <div class="main-menu">
        <nav>
            <ul>
                <li class="active sub-menu"><a href="index.html">home <span class="fa fa-angle-down"></span></a>
                    <ul class="sub-menu-item">
                        <li><a href="index.html">home one</a></li>
                        <li><a href="index2.html">home two</a></li>
                        <li><a href="index3.html">home three</a></li>
                        <li><a href="index4.html">home four</a></li>
                        <li><a href="index5.html">home five</a></li>
                    </ul>
                </li>
                <li><a href="profile.html">Profile</a></li>
                <li><a href="travel.html">Travel</a></li>
                <li><a href="portfolio.html">portfolio</a></li>
                <li><a href="blog-details.html">blog</a></li>
                <li><a href="contact.html">contact us</a></li>
            </ul>
        </nav>
    </div>
</div>