<?php get_template_part('template-parts/header'); ?>
<?php get_sidebar('menu'); ?>
<div class="container">
    <div class="row">
        <p>Không có nội dung</p>
    </div>
</div>
<?php get_template_part('template-parts/footer'); ?>

