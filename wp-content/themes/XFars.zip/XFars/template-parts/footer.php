<!-- footer area start here -->
    <footer class="footer-area">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="footer-widget widget-text">
                            <div class="footer-logo">
                                <h2><a href="#">Xfar </a></h2>
                            </div>
                            <div class="widget-content">
                                <p>Lorem Ipsum is simply dummy
                                    text of the printing and typesetting
                                    industry. Lorem Ipsum has been
                                    the industry's standard dummy
                                    text ever since the 1500s, when an
                                    unknown printer took a galley of
                                    type and scrambled it to make a
                                    type specimen book. It has survive
                                    not only five centuries, but also the
                                    leap into electronic typesetting, </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="footer-widget widget-nave">
                            <div class="widget-title">
                                <h3>Quick Link</h3>
                            </div>
                            <div class="widget-nave-list">
                                <ul>
                                    <li><a href="#">Fashion </a></li>
                                    <li><a href="#">Life style</a></li>
                                    <li><a href="#">Creative</a></li>
                                    <li><a href="#">Traveling</a></li>
                                    <li><a href="#">Guide</a></li>
                                    <li><a href="#">World Tour</a></li>
                                    <li><a href="#">Ship Tour</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="footer-widget widget-recent-post">
                            <div class="widget-title">
                                <h3>Recent Post</h3>
                            </div>
                            <div class="recent-post-list">
                                <div class="single-post">
                                    <p><a href="#">We denounce with righteou
                                            indignation and dislike</a></p>
                                </div>
                                <div class="single-post">
                                    <p><a href="#">We denounce with righteou
                                            indignation and dislike</a></p>
                                </div>
                                <div class="single-post last">
                                    <p><a href="#">We denounce with righteou
                                            indignation and dislike</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="footer-widget widget-Subscribe">
                            <div class="widget-title">
                                <h3>Subscribe Us</h3>
                            </div>
                            <div class="widget-Subscribe-form">
                                <form action="#">
                                    <div class="from-grupe">
                                        <input type="email" name="email" placeholder="Enter your email" id="email">
                                        <button type="submit" class="submit-btn">Submit</button>
                                    </div>
                                </form>
                            </div>
                            <div class="widget-content">
                                <p>Blinded by desire, that they can
                                    foresee the pain and trouble that
                                    are bound to ensue</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="copyright-area">
                            <p>&copy; 2018 Xfar . All rights Reserved.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="footer-right text-right">
                            <p>Design By <a href="#">Createuiux</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>
    </body>
</html>