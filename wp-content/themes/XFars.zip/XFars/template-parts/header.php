<!DOCTYPE HTML>
<html class="no-js" <?php language_attributes(); ?>>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <meta charset="<?php bloginfo('charset') ?>">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="author" content="smartit-source">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- title here -->
    <title>
        <?php 
            wp_title('|',true,'right'); 
            bloginfo('name');
        ?>
    </title>
    <link rel="pingback" href="<?php bloginfo('pingback_url');  ?>">
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">

    <!-- Favicon and Touch Icons -->
    <link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/assets/images/fav.png">
    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="apple-touch-icon.html">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
    
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <!-- header area start here -->
    <header class="header-area header-one" id="sticky">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-xs-6">
                    <div class="log-area">
                        <a href="index.html"><img src="<?php bloginfo('template_directory'); ?>/assets/images/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="menu-area">
                        <nav>
                            <ul>
                                <li class="active sub"><a href="index.html">home <span class="fa fa-angle-down"></span></a>
                                    <ul class="sub-menu">
                                        <li><a href="index.html">home one</a></li>
                                        <li><a href="index2.html">home two</a></li>
                                        <li><a href="index3.html">home three</a></li>
                                        <li><a href="index4.html">home four</a></li>
                                        <li><a href="index5.html">home five</a></li>
                                    </ul>
                                </li>
                                <li><a href="profile.html">Profile</a></li>
                                <li><a href="travel.html">Travel</a></li>
                                <li><a href="portfolio.html">portfolio</a></li>
                                <li><a href="blog-details.html">blog</a></li>
                                <li><a href="contact.html">contact us</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-md-1 col-xs-6">
                    <div class="humbargar-area">
                        <div class="menu-icon text-right">
                            <span class="flaticon-menu humbargar"></span>
                        </div>
                        <div class="close-area">
                            <span class="close"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header area start here -->