<div class="col-lg-10 col-lg-offset-1 col-md-12">
    <div class="pagination-area">
        <div class="pagination">
        <?php echo xfars_pagination(); ?>
        </div>
    </div>
</div>