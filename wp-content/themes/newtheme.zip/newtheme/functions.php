<?php
global $theme_prefix,$theme_uri;
$theme_prefix   = 'newtheme';
$theme_uri      = get_template_directory_uri().'/assets';
$theme_dir      = get_template_directory();
$theme_version  = '1.0';

// Đăng ký các thành phần hỗ trợ cho theme: menu, post_thumbnail...
include_once $theme_dir.'/inc/theme_support.php';

// Đăng ký style,scripts cho theme: css, js
include_once $theme_dir.'/inc/scripts.php';

// Đăng ký sidebar, widgets
include_once $theme_dir.'/inc/widgets.php';

// Đăng ký customizer
include_once $theme_dir.'/inc/customizers.php';

// Đăng ký shortcodes
include_once $theme_dir.'/inc/shortcodes.php';

// Tạo custom post type product

function create_post_type() {
    $label = array(
        'name' => 'Sản phẩm',
        'singular_name' => 'Sản phẩm'
    );

    $args = array(
        'labels' => $label,
        'description' => 'Post type đăng sản phẩm',
        'supports' => array(
            'title',
            'editor',
            'excerpt',  // mô tả ngắn cho sản phẩm
            'author',
            'thumbnail',
            'comments',
            'custom-fields',
            'revisions'
        ),
        'taxonomies' => array( 'category', 'post_tag' ),
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 3,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'show_in_admin_bar' => true,
        'menu_icon' => 'dashicons-cart',
        'capability_type' => 'post'
    );
    register_post_type('product', $args);
}
add_action( 'init', 'create_post_type' );


/**
 * hiển thị danh sách các bài post type ra trang chủ bao gồm post type post và product
 */
add_filter('pre_get_posts','get_custom_post_type');
function get_custom_post_type($query) {
  if (is_home() && $query->is_main_query ())
    $query->set ('post_type', array ('post','product'));
    return $query;
}

