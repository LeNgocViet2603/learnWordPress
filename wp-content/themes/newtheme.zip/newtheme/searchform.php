<div class="blog__sidebar__search">
    <form action="<?= home_url();?>" method="GET">
        <input type="text" name="s" placeholder="Search...">
        <button type="submit"><span class="icon_search"></span></button>
    </form>
</div>