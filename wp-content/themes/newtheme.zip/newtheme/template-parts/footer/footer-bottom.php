<div class="row">
    <div class="col-lg-12">
        <div class="footer__copyright">
            <div class="footer__copyright__text">
                <p>
                    Copyright &copy; <?= date('Y')?> All rights reserved
                </p>
            </div>
            <div class="footer__copyright__payment">
                <img src="<?= $theme_uri; ?>/img/payment-item.png" alt="">
            </div>
        </div>
    </div>
</div>