<div class="row">
    <div class="col-lg-3 col-md-6 col-sm-6">
        <?php dynamic_sidebar('footer-1'); ?>
    </div>
    <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-1">
        <?php dynamic_sidebar('footer-2'); ?>
    </div>
    <div class="col-lg-4 col-md-12">
        <?php dynamic_sidebar('footer-3'); ?>
    </div>
</div>